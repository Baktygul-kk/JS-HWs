

/*Классная работа*/
document.writeln("<h2> Class work </h2> <br>");
/*let user = prompt("Как тебя зовут?");
document.write("Привет, " + user+"! <br>");

let clubName= prompt("Введите название любимой футбольной команды ");
document.write(clubName.toUpperCase()+" это чемпион <br>");

let card= prompt("Введите номер карты: (16 цифр)");
//document.write(card.charAt(15),card.charAt(14),card.charAt(13),card.charAt(12)); //можно и так, но слишком длинный код получится
document.write("Последние 4 цифры карты: "+card.slice(12));*/




/*Домашняя работа*/
document.writeln("<h2> Home work </h2> <br>");

/*задание №3 */



/*задание №1 */
let userName="иВан";
document.write("1. "+userName+" - неправильно написано <br>");
let newName=userName[0].toUpperCase()+userName.slice(1).toLowerCase();
document.write(newName+" - первый вариант <br>");
document.write(userName.replace("иВан", "Иван")+" - второй вариант <br>");

/*задание №2 */
let myString="$120";
document.write("2. "+myString+" - оригинал <br>");
document.write(myString.slice(1)+" без знака $ <br>");//первый вариант

let str=myString.slice(1);
let num = Number(str);//второй вариант
document.write(num+" второй вариант из строки в число <br>");

/*задание №3 */
/*let userName = prompt("Здравствуй, я компьютер, а тебя как зовут?");
let age =prompt("Очень приятно, "+ userName+". Сколько тебе лет? <br>");
document.writeln("Здравствуй, я компьютер, а тебя как зовут?");
document.writeln("Очень приятно, "+ userName+". Сколько тебе лет? <br>");
document.writeln("Ого! Тебе уже "+ age +"! <br>");*/ //не работает здесь, но в консоли браузера работает

/*задание №4 */
let myCard= prompt("Введите номер карты: (16 цифр)");
let hideNum = ("************"+myCard.slice(12));
document.write("4. Последние 4 цифры карты: "+hideNum);