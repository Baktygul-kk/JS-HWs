

document.write(`<h1>Классная работа</h1>`);
document.write(`<h2>Задача №1</h2>`);
document.write(`1. Имеется массив из 20 чисел. Вывести на экран только четные числа из массива <br> Четные числа: <br>`);
for (let i=1; i<21; i++){
    if (i%2==0)
    document.write(i+"<br>");
}



document.write(`<h2>Задача №2</h2>`);
document.write(`Имеется массив строк с 10 элементами. Вывести на экран самое длинное слово из массива <br>`);
let people=["Alice","Tom","Nike","Lili","Alexandre","Yoko","Kim","Misha","Tokon","Anna"];
for(let user of people){
    document.write(user+"<br>");
}
 let sorted = people.sort((a, b) => b.length - a.length );
document.write("длинное слово из массива: "+sorted[0]+"<br>");




document.write(`<h2>Задача №3</h2>`);
document.write(`Массовое удаление. Имеется массив, который содержит имена 15 пользователей. Необходимо удалить всех пользователей. При удалении каждого пользователя нужно выводить сообщения:<br>  
«Удаляю пользователя Иван»<br>
«Удаляю пользователя Вася»<br>… <br>`);

let users=["Alice","Tom","Nike","Lili","Alexandre","Yoko","Kim","Misha","Tokon","Anna"];
for(let d of users){
    document.write(d+"<br>");
}
let u=0;
do {
    document.write(`Удаляю пользователя  ${users.pop()} <br>`);
    u++;
  } while (u < users.length);



  document.write(`<h1>Домашняя работа</h1>`);
  document.write(`<h2>Задача №1</h2>`);
  document.write(`1. Строка называется палиндромом, если она пишется одинаково в обоих
  направлениях. Например, палиндромами в английском языке являются
  слова «anna», «civic», «level», «hannah». Напишите программу, запраши-
  вающую у пользователя строку и при помощи цикла определяющую, яв-
  ляется ли она палиндромом. <br>`);
  /*let word=prompt(`Введите слово для определения`);
  for (let w=0; w<word.length; w++){
      if(word[w]){
          let pol=word.length/2;
          document.write(`палиндром`);
      }else document.write(`ytпалиндром`);
  }*/

  let userInput = "анна";
  let isPalindrome = true;

    for (let i = 0; i < userInput.length / 2 && isPalindrome; i++) {
    if (userInput[i] !== userInput[userInput.length - i - 1]) {
        isPalindrome = false;
    }
    }
    isPalindrome ? document.write("Palindrome") : document.write("Not a palindrome");//решение агая



    document.write(`<h2>Задача №2</h2>`);

    for (let k=1; k<10; k++){
        for(let j=0; j<10; j++){
            let result= k*j;
            document.write(`${k}*${j}= ${result}<br>`);
        }
        document.write("<br>");
    }