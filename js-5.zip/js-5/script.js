/*Классная работа*/
/*Задача №1*/
let lang=prompt("Введите язык 'ru' или 'ky'");
if (lang==="ru"){
    console.log("Привеет!");
}else if (lang==="ky"){
    console.log("Салам!");
}else console.log("Я не знаю такого языка");


/*Задача №2*/
let str='abcde';
if (str[0]=="a"){
    console.log("da");
}else console.log("net");


/*Задача №3*/
let num="12345";
if(num[0]==1 || num[0]==2 || num[0]==3){
    console.log("da");
}else console.log("net");




/*Домашняя работа*/

/*Задача №1*/
let numD=+prompt("Введите любое число");
if (numD%2==0){
    document.write("четное <br>");
} else document.write("нечетное <br>");


/*Задача №2*/
let month = prompt("Введите название месяца, чтоб определить время года");
if (month=="январь" || month=="февраль" || month=="декабрь"){
    document.write("это зима <br>");
}else if (month=="март" || month=="апрель" || month=="май"){
    document.write("это весна <br>");
}else if (month=="июнь" || month=="июль" || month=="август"){
    document.write("это лето <br>");
}else if (month=="сентябрь" || month=="октябрь" || month=="ноябрь"){
    document.write("это осень <br>");
} 





/*Задача №3*/
let yearsM=[2020, 2008, 1996, 1984, 1972, 1960, 1948, 1936];
let year=+prompt("Введите год рождения чтобы узнать зодиак");

for (let i = 0; i < yearsM.length; i++) {
  if (yearsM[i]==year){
      document.write("Rat, ");
  }
}

let yearsC=[2021, 2009, 1997, 1985, 1973, 1961, 1949, 1937];

for (let j = 0; j < yearsC.length; j++) {
  if (yearsC[j]==year){
      document.write("Cow, ");
  }
}

let yearsT=[2022, 2010, 1998, 1986, 1974, 1962, 1950, 1938];

for (let j = 0; j < yearsT.length; j++) {
  if (yearsT[j]==year){
      document.write("Tiger, ");
  }
}


let yearsRabbit=[2023, 2011, 1999, 1987, 1975, 1963, 1951, 1939];

for (let j = 0; j < yearsRabbit.length; j++) {
  if (yearsRabbit[j]==year){
      document.write("Rabbit, ");
  }
}


let yearsDragon=[2024, 2012, 2000, 1988, 1976, 1964, 1952, 1940];

for (let j = 0; j < yearsDragon.length; j++) {
  if (yearsDragon[j]==year){
      document.write("Dragon, ");
  }
}


let yearsSnake=[2025, 2013, 2001, 1989, 1977, 1965, 1953, 1941];
for (let j = 0; j < yearsSnake.length; j++) {
  if (yearsSnake[j]==year){
      document.write("Snake, ");
  }
}


let yearsHorse=[2026, 2014, 2002, 1990, 1978, 1966, 1954, 1942];
for (let j = 0; j < yearsHorse.length; j++) {
  if (yearsHorse[j]==year){
      document.write("Horse, ");
  }
}

let yearsGoat=[2027, 2015, 2003, 1991, 1979, 1967, 1955, 1943];
for (let j = 0; j < yearsGoat.length; j++) {
  if (yearsGoat[j]==year){
      document.write("Goat, ");
  }
}

let yearsMonkey=[2028, 2016, 2004, 1992, 1980, 1968, 1956, 1944];
for (let j = 0; j < yearsMonkey.length; j++) {
  if (yearsMonkey[j]==year){
      document.write("Monkey, ");
  }
}

let yearsRooster=[2029, 2017, 2005, 1993, 1981, 1969, 1957, 1945];
for (let j = 0; j < yearsRooster.length; j++) {
  if (yearsRooster[j]==year){
      document.write("Rooster, ");
  }
}

let yearsDog=[2030, 2018, 2006, 1994, 1982, 1970, 1958, 1946];
for (let j = 0; j < yearsDog.length; j++) {
  if (yearsDog[j]==year){
      document.write("Dog, ");
  }
}

let yearPig=[2031, 2019, 2007, 1995, 1983, 1971, 1959, 1947];
for (let j = 0; j < yearPig.length; j++) {
  if (yearPig[j]==year){
      document.write("Pig, ");
  }
}