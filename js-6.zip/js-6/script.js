/*1. Разработайте программу, запрашивающую у пользователя букву латинского алфавита.
 Если введенная буква входит в следующий список (a, e, i, o или u), необходимо вывести сообщение о том, что эта буква гласная.
  Если была введена буква **y**, программа должна написать, что эта буква может быть как гласной, так и согласной.
   Во всех других случаях должно выводиться сообщение о том, что введена согласная буква.

2. Напишите программу, запрашивающую у пользователя три целых числа и выводящую их в упорядоченном виде – по возрастанию.*/ 


//Классная работа
/*let letter=prompt("Введите букву латинского алфавита:");
switch(letter){
    case "a":
    case "o":
    case "e":
    case "u":
    case "i":
    console.log("гласная");
    break;
    case "y":
    console.log("и гласная и согласная");
    break;
    default:
     console.log("согласная");
}


let array=[45,32,57,98,100,7,5];
console.log(array);
array.sort( (a, b) => a - b );
console.log(array);
document.write(array+"по возростанию<br>");
document.write(array.reverse()+" по убыванию <br>");*/






//Домашняя работа

document.write("<h2>Задача №1 </h2> ");

let volume=+prompt("Введите уровень шума в децибелах");
document.write(`уровень громкости в децибелах = ${volume} это =`);
if(volume===130){
     document.write("Отбойный молоток");
}else if(129>=volume && 107<=volume){
     document.write("Между отбойным молотком и газовой газонокосилкой");
}else if(volume===106){
     document.write("Газовая газонокосилка");
}else if(105<=volume && 71>=volume){
    document.write("Газовая газонокосилка и Будильник ");
}else  if(volume===70){
     document.write("Будильник ");
}else if(69<=volume && 41>=volume){
    document.write("Будильник и Тихая комната");
}else if (volume===40){
     document.write("Тихая комната");
}else if(volume>130){
     document.write("максимальный звук");
}else if(volume<40){
     document.write("минимальный звук");
}



document.write("<h2>Задача №2 </h2> ");

let money=+prompt("Введите номинал банкноты");
document.write(`номинал банкноты = ${money} это = `);
switch (money){
    case 1:
    document.write("Джордж Вашингтон");
    break;
    case 2:
    document.write("Томас Джефферсон");
    break;
    case 5:
    document.write("Авраам Линкольн");
    break;
    case 10:
    document.write("Александр Гамильтон");
    break;
    case 20:
    document.write("Эндрю Джексон");
    break;
    case 50:
    document.write("Улисс Грант");
    break;
    case 100:
    document.write("Бенджамин Франклин");
    break;
    default:
     document.write("такого номинала не существует");

}



document.write("<h2>Задача №3 не смогла </h2> ");