alert("Hello, I am Kozhoshova Baktygul");

console.log("Baktygul "+"kozhoshova");//конкатенация
console.log(100 + 100);//вывод в консоли
console.log("hi from console");

document.write("<p>Baktygul Kozhoshova</p>");// вывод в браузер
document.write("100 + 100 = " + (100 + 100));// вывод в браузер
document.write("<h1>Привет!</h1>  <p>Это мой первый скрипт!</p>");