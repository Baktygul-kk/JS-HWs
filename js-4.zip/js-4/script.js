/*Задача №1*/
document.write("<strong>Задача №1 </strong><br>");
document.write("суммa натуральных положительных чисел от 1 до введенного значения. <br>");
let num= prompt("Введите число");
let changeType=Number(num);
document.write(`введенное число ${changeType} <br> `);
let formula =changeType * (changeType + 1) / 2;
document.write(`сумма чисел равна ${formula} <br>`);



/*Задача №2*/
document.write("<strong>Задача №2 </strong><br>");
document.write("<strong>Надо найти общий вес посылки </strong><br>");
let souvenir=prompt ("Введите количество сувенира");
let bauble =prompt("Введите количество безделушек");
const WEIGHT_SUV =75;
const WEIGHT_BAUBLE=112;
let generalWeight=souvenir*WEIGHT_SUV+bauble*WEIGHT_BAUBLE;
document.write(`общий вес равен ${generalWeight} гр <br>`);




/*Задача №3*/
document.write("<strong>Задача №3 </strong><br>");
let startSum =prompt(`Внесите первоначальный взнос`);
const INTEREST_RATE=0.04;

let firstYear=(1+INTEREST_RATE)**1*startSum;
let secondYear=(1+INTEREST_RATE)**2*startSum;
let thirdYear=(1+INTEREST_RATE)**3*startSum;

document.write(`на счету в конце первого года ${firstYear.toFixed(2)} <br>`);
document.write(`на счету в конце второго года ${secondYear.toFixed(2)} <br>`);
document.write(`на счету в конце третьего года ${thirdYear.toFixed(2)} <br>`);





/*Задача №4*/
document.write("<strong>Задача №4 </strong><br>");
let numA=prompt("Введите число А ");
let numB=prompt("Введите число B ");
let a=Number(numA);
let b=Number(numB);

let sum =a+b;
let minus=a-b;
let multi=a*b;
let divide=a/b;
let remainder=a%b;
let raising=a**b;

document.write(`Введенные цифры А равен ${a} <br> B равен ${b} <br>`);

document.write(`${sum}  сумма a и b; <br>`);
document.write(`${minus}  разница между a и b; <br>`);
document.write(`${multi}  произведение a и b; <br>`);
document.write(`${divide.toFixed(2)}  частное от деления a на b; <br>`);
document.write(`${remainder}  остаток от деления a на b; <br>`);
document.write(`${raising}  результат возведения числа a в степень b.<br>`);